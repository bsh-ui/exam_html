package com.lgy.item_mybatis_oracle.dao;

import java.util.ArrayList;
import java.util.List;

import com.lgy.item_mybatis_oracle.dto.ItemDTO;

public interface ItemDAO {
	void insertItem(ItemDTO dto);
	List<ItemDTO> selectAll();
	
}
