package com.lgy.item_mybatis_oracle.controller;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lgy.item_mybatis_oracle.dao.ItemDAO;
import com.lgy.item_mybatis_oracle.dto.ItemDTO;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class ItemController {

    @Autowired
    private SqlSession sqlSession;

    @RequestMapping("/write_view")
    public String write_view() {
        return "item_write";
    }

    @RequestMapping("/write_result")
    public String write_result(@ModelAttribute ItemDTO item, Model model) {
        ItemDAO dao = sqlSession.getMapper(ItemDAO.class);
        dao.insertItem(item);
        model.addAttribute("item", item);
        return "write_result";
    }

    @RequestMapping("/content_view")
    public String content_view(Model model) {
        ItemDAO dao = sqlSession.getMapper(ItemDAO.class);
        model.addAttribute("items", dao.selectAll());
        return "content_view";
    }
}
